var http = require('http');
var express = require('express')
var parser = require('body-parser')
var exp = express();
var fs = require('fs');
var cors = require('cors')
var MongoClient = require('mongodb').MongoClient; //port 27017


exp.use(cors());

//get api to get data
exp.get("/rest/api/load", cors(), (req, res) => {
    console.log("Load Invoked")
    res.send({ msg: 'give some rest to world' })
})
//get api to get data
exp.route("/rest/api/get", cors()).get((req, res) => {
    console.log("Load Invoked")
    res.send({ msg: 'give some rest to world' })
})



//parsing of body
exp.use(parser.json());
//1.post api for database insertion
exp.route('/rest/api/post', cors()).post((req, res) => {
    console.log(req.body);
    fs.writeFileSync('demo.json', JSON.stringify(req.body))
    fs.readFile('demo.json', (err, data) => {
        console.log("hii data is " + data);
    });
    res.status(201).send(req.body);
    //inserting in database
    MongoClient.connect("mongodb://localhost:27017/test", function (err, dbVar) {
        if (err) throw err;
        var coll = dbVar.db("test");
        coll.collection("test").insert(req.body, true, function (err, res) {
            if (err) throw err;
            console.log("1 document inserted");
            dbVar.close();
        });
        dbVar.close();
    });
})

//2.post api for database retrival
exp.route("/rest/api/getAlldbData", cors()).get((req, res) => {
    console.log("Load Invoked")
    // res.send({ msg: 'give some rest to world' })
    MongoClient.connect("mongodb://localhost:27017/test", function (err, dbVar) {
        if (err) throw err;
        var coll = dbVar.db("test");
        coll.collection("test").find().toArray(function (err, result) {
            if (err) throw err;
            console.log(result);
            res.send(result)
            dbVar.close();
        });
        dbVar.close();
    });
})


//3.json file to database
exp.route('/rest/api/file2db', cors()).post((req, res) => {
    console.log('file2db Invoked....');
    var fileData;
    fs.readFile('dmyData.json', function (err, data) {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        fileData = JSON.parse(data.toLocaleString());
        console.log(fileData);
        res.end();
    });
    MongoClient.connect('mongodb://localhost:27017/test', function (err, dbvar) {
        console.log('In Mongo Client', fileData);
        if (err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').insertMany(fileData, true, function (err, res) {
            if (err) throw err;
            console.log('One document inserted....');
            dbvar.close();
        });
        dbvar.close();
    });
})

//4.delete specific data from  database
exp.route('/rest/api/deleteData', cors()).post((req, res) => {
    console.log("id isxxxx: "+(req.body).id);
    res.status(201).send(req.body);
    MongoClient.connect("mongodb://localhost:27017/test", function (err, dbVar) {
        if (err) throw err;
        var coll = dbVar.db('test');
        coll.collection('test').deleteMany({"name": (req.body).name}, function (err, obj) {
            if (err) throw err;
            console.log("1 document deleted");
            dbVar.close();
        });
        dbVar.close();
    });
})


/**
 * Service for updating data
 */

exp.route('/rest/api/put', cors()).put((req, res)=>{

    MongoClient.connect('mongodb://localhost:27017/test', { useNewUrlParser: true }, function(err, dbvar){
        console.log('In Mongo Client PUT',(req.body).name);
        if(err) throw err;
        var coll = dbvar.db('test');
        
        coll.collection('test').updateOne({name: (req.body).name}, {$set: {age: (req.body).age}}, true, function(err, result){
            if(err) throw err;
            console.log('One document Updated....');
            res.end();
            dbvar.close();
        });
        dbvar.close();
    });
})


exp.use(cors()).listen(3000, () => console.log("running"));
